// Run using
//
//    r.js -o build.js
//
// Keep this in sync with swish.js.  There must be another way to do this ...

({ baseURL: ".",
   
  waitSeconds: 60,			/* swish-min.js is big */
  paths:
  { jquery:      "../node_modules/jquery/dist/jquery.min",
    "jquery-ui": "../node_modules/jquery-ui/jquery-ui.min",
    laconic:     "../node_modules/laconic/laconic",
    bootstrap:   "../node_modules/bootstrap/dist/js/bootstrap.min",
    bloodhound:  "../node_modules/typeahead.js/dist/bloodhound",
    typeahead:   "../node_modules/typeahead.js/dist/typeahead.jquery",
    splitter:    "../node_modules/jquery.splitter/js/jquery.splitter-0.15.0",
    tagmanager:  "../node_modules/tagmanager/tagmanager",
    sha1:        "../node_modules/js-sha1/src/sha1",
    c3:          "../node_modules/c3/c3",
    d3:          "../node_modules/d3/d3",
    printThis:   "../node_modules/printthis/printThis",
    "svg-pan-zoom": "../node_modules/svg-pan-zoom/dist/svg-pan-zoom.min",
    sparkline:	 "../node_modules/sparkline/dist/jquery.sparkline",

					/* CodeMirror extensions */
    "cm/mode/prolog": "codemirror/mode/prolog",
    "cm/addon/hover/prolog-hover": "codemirror/addon/hover/prolog-hover",
    "cm/addon/hover/text-hover": "codemirror/addon/hover/text-hover",
    "cm/addon/hint/templates-hint": "codemirror/addon/hint/templates-hint",
    "cm/addon/hint/show-context-info": "codemirror/addon/hint/show-context-info",

					/* Standard CodeMirror */
    "cm" : "../node_modules/codemirror"
  },
  shim:
  { bootstrap:
    { deps:["jquery"]
    },
    typeahead: /* HACK: See https://github.com/twitter/typeahead.js/issues/1211 */
    { deps:["jquery"],
      init: function ($) {
	return require.s.contexts._.registry['typeahead.js'].factory($);
      }
    },
    bloodhound:
    { deps:["jquery"]
    },
    splitter:
    { deps:["jquery"]
    },
    laconic:
    { deps:["jquery"]
    },
    tagmanager:
    { deps:["jquery"]
    },
  },

   generateSourceMaps: true,
   preserveLicenseComments: false,

   name: "swish",
   out: "swish-min.js.new"
})
