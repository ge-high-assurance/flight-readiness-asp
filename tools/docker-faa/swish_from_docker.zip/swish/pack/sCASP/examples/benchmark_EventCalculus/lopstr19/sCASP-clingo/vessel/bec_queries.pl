?- holdsAt(level(L),15/2).
?- holdsAt(level(14),T).
?- holdsAt(level(L),15/2).
?- holdsAt(level(10/3),T).
?- holdsAt(level(12),14).
?- holdsAt(spilling,T).
?- holdsAt(level(11),T).