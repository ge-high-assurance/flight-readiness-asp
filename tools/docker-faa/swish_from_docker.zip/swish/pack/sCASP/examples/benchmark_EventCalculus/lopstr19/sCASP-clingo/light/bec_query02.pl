?- holdsAt(light_red, 6.99).                            % success  
