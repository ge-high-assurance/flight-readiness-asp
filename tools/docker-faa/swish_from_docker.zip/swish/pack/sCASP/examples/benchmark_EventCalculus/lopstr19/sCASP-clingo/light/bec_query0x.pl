?- holdsAt(light_red, T).                            % success  
