%% USED to select an instance to the benchmarcks....


% :- include('instances/01-weight_assignment_tree-654-0.asp').
% :- include('instances/02-weight_assignment_tree-687-0.asp'). 
% :- include('instances/03-weight_assignment_tree-742-0.asp'). 
% :- include('instances/04-weight_assignment_tree-612-0.asp'). 
% :- include('instances/05-weight_assignment_tree-579-0.asp'). 
% :- include('instances/06-weight_assignment_tree-560-0.asp'). 
% :- include('instances/07-weight_assignment_tree-547-0.asp'). 
% :- include('instances/08-weight_assignment_tree-806-0.asp'). 
% :- include('instances/09-weight_assignment_tree-778-0.asp'). 
% :- include('instances/10-weight_assignment_tree-938-0.asp'). 
% :- include('instances/11-weight_assignment_tree-934-0.asp'). 
% :- include('instances/12-weight_assignment_tree-918-0.asp'). 
% :- include('instances/13-weight_assignment_tree-901-0.asp'). 
 :- include('instances/14-weight_assignment_tree-1070-0.asp').
% ...
% :- include('instances/60-weight_assignment_tree-1588-0.asp').
% :- include('instances/61-weight_assignment_tree-1542-0.asp').
% :- include('instances/62-weight_assignment_tree-2102-0.asp').

%% EXAMPLE
% leafWeightCardinality(leaf1, 4, 5).
% leafWeightCardinality(leaf2, 3, 7).

% innerNode(1).

% num(2).
% max_total_weight(9).
%% EXAMPLE
