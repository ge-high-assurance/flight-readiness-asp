% { p(_), not q(_) }
#include('pq_loop.lp').
#include 'member.lp'.
