p(X) :- X \= Y, q(Y).
q(X) :- X \= Y, p(X).

#compute 1 {p(X)}.
