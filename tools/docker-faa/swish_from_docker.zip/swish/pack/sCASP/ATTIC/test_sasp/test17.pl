% { p, not q }
p :- not q.
:- not p.
