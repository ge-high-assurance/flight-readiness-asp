p :- not q.
q :- not p.


