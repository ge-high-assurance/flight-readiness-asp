p(X) :- p(Y).
?- p(X).
