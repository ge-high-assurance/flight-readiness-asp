p:-q.
q:-p.

?- p.