p(X) :-   not p(3), q(X).

p(1).
q(2).

s.

?- p(X).