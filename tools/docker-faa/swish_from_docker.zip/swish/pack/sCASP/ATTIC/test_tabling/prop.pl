s(1).
s(X) :- s(X).


?-  not s(X).


