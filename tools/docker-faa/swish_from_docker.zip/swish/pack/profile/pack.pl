name(profile).
version('0.1.0').
title('Manage user profiles').
keywords([user, profile, http]).
author( 'Jan Wielemaker', 'jan@swi-prolog.org' ).
home('https://github.com/JanWielemaker/profile' ).
download( 'https://github.com/JanWielemaker/profile/releases/*.zip' ).
